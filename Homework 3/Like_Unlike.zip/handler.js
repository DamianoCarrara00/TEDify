const connect_to_db = require('./db');
const Talk = require('./Talk'); 

module.exports.like_unlike = async (event, context, callback) => {
  context.callbackWaitsForEmptyEventLoop = false;

  try {
    console.log('Received event:', JSON.stringify(event, null, 2));

    let body = event.body ? JSON.parse(event.body) : {};
    const { videoId, userId } = body;

    if (!videoId || !userId) {
      return callback(null, {
        statusCode: 400,
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ message: 'Missing videoId or userId' })
      });
    }

    await connect_to_db();
    console.log('=> Connected to DB');

    const talk = await Talk.findOne({ _id: videoId });

    if (!talk) {
      return callback(null, {
        statusCode: 404,
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ message: 'Video not found' })
      });
    }

    let hasLiked = talk.likes && talk.likes.includes(userId);

    const update = hasLiked
      ? { $pull: { likes: userId } }
      : { $addToSet: { likes: userId } };

    await Talk.updateOne({ _id: videoId }, update);

    return callback(null, {
      statusCode: 200,
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        liked: !hasLiked,
        message: hasLiked ? 'Like removed' : 'Like added'
      })
    });

  } catch (err) {
    console.error('Error occurred:', err);
    return callback(null, {
      statusCode: 500,
      headers: { 'Content-Type': 'text/plain' },
      body: 'Internal server error: ' + err.message
    });
  }
};
