const connect_to_db = require('./db');
const talk = require('./Talk');

module.exports.get_watchnext_by_idx = async (event, context, callback) => {
  context.callbackWaitsForEmptyEventLoop = false;

  try {
    console.log('Received event:', JSON.stringify(event, null, 2));

    const body = event.body ? JSON.parse(event.body) : {};
    const { idx, doc_per_page = 10, page = 1 } = body;

    if (!idx) {
      return callback(null, {
        statusCode: 400,
        body: 'Missing idx in request.'
      });
    }

    await connect_to_db();
    console.log('=> Connected to MongoDB');

    const talks = await talk.find({ _id: idx })
      .skip((doc_per_page * page) - doc_per_page)
      .limit(doc_per_page);

    if (!talks || talks.length === 0) {
      return callback(null, {
        statusCode: 404,
        body: 'No talk found with the given idx.'
      });
    }

    const watch_next_ids = (talks[0].Watch_next_id || []).map(String);

    const watchnext = await talk.find({ _id: { $in: watch_next_ids } });

    if (!watchnext || watchnext.length === 0) {
      return callback(null, {
        statusCode: 200,
        body: JSON.stringify({
          message: "Watch next non presenti nel dataset.",
          suggestions: []
        })
      });
    }
    
    return callback(null, {
      statusCode: 200,
      body: JSON.stringify(watchnext)
    });

  } catch (err) {
    console.error('Unexpected error:', err);
    return callback(null, {
      statusCode: 500,
      body: 'Internal server error: ' + err.message
    });
  }
};
